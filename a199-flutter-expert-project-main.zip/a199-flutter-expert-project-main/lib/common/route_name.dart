const kRouteNamePopularTvSeries = '/popular-tv-series';
const kRouteNameTopRatedTvSeries = '/top-rated-tv-series';
const kRouteNameTvSeriesDetail = '/tv-series-detail';
const kRouteNameSearchTvSeries = '/search-tv-series';
const kRouteNameWatchlistTvSeries = '/watchlist-tv-series';
